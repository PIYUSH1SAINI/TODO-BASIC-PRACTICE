"use client";

import React, { use, useState } from "react";
import { Todo, TodoProps } from "@/types/todo";

const TodoDisplay = ({ handleDelete, handleEdit, todos }: TodoProps) => {
  const [editId, setEditId] = useState("");
  const [editName, setEditName] = useState("");

  return (
    <div className="mx-10 flex flex-row gap-5 flex-wrap">
      {todos.length > 0 ? (
        todos.map((task) => (
          <div className="bg-white/10 w-fit rounded-lg text-center p-5">
            {editId == task._id ? (
              <div className="flex flex-row gap-2 mb-2">
                <input
                  type="text"
                  placeholder="Enter Task name"
                  className="border-1 rounded-lg px-2"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                />
                <button
                  className="bg-green-600 p-2 rounded-lg"
                  onClick={() => {
                    handleEdit(editName, editId);
                    setEditId("");
                  }}
                >
                  Save Changes
                </button>
              </div>
            ) : (
              <p className="pb-3 font-bold">{task.taskName}</p>
            )}

            <div className="flex flex-row w-full gap-2">
              <button
                onClick={() => handleDelete(task._id)}
                className="border-1 p-2 border-red-500 rounded-lg"
              >
                Delete
              </button>
              <button
                onClick={() => {
                  setEditId(task._id);
                  setEditName(task.taskName);
                }}
                className="border-1 p-2 border-gray-500 rounded-lg"
              >
                Edit
              </button>
            </div>
          </div>
        ))
      ) : (
        <h1>No tasks</h1>
      )}
    </div>
  );
};

export default TodoDisplay;
