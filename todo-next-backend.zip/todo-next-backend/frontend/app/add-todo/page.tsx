"use client";

import axios from "axios";
import React, { useState } from "react";
import { useRouter } from "next/navigation";

const AddEditTodo = () => {
  const router = useRouter();
  const [taskName, setTaskName] = useState("");

  const handleAdd = async (todoName: string) => {
    try {
      const newTodo = await axios.post(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/addTodo`,
        {
          taskName: todoName,
        }
      );
      console.log("Added");

      router.push("/");
    } catch (err) {
      console.log("error Adding todo: ", err);
    }
  };

  return (
    <div className="flex flex-row gap-2 justify-center mt-50">
      <h1 className="text-4xl">Add a Task :</h1>
      <input
        type="text"
        placeholder="Enter Task name"
        className="border-1 rounded-lg px-2"
        value={taskName}
        onChange={(e) => setTaskName(e.target.value)}
      />

      <button
        className="bg-green-600 p-2 rounded-lg"
        onClick={() => handleAdd(taskName)}
      >
        Add
      </button>
    </div>
  );
};

export default AddEditTodo;
