"use client";

import Image from "next/image";
import TodoDisplay from "./components/TodoDisplay";
import AddEditTodo from "./add-todo/page";
import Link from "next/link";

import axios from "axios";
import { useEffect, useState } from "react";

export default function Home() {
  const [todo, setTodo] = useState([]);

  useEffect(() => {
    fetchTodo();
  }, []);

  const fetchTodo = async () => {
    try {
      const todos = await axios.get(process.env.NEXT_PUBLIC_BACKEND_URL!);
      setTodo(todos.data);
    } catch (err) {
      console.log("error editing: ", err);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await axios.delete(`${process.env.NEXT_PUBLIC_BACKEND_URL}/${id}`);

      console.log("Deleted");

      fetchTodo();
    } catch (err) {
      console.log("error deleting: ", err);
    }
  };

  const handleEdit = async (taskName: string, id: string) => {
    try {
      const edited = await axios.put(
        `${process.env.NEXT_PUBLIC_BACKEND_URL}/${id}`,
        {
          taskName,
        }
      );

      fetchTodo();

      console.log("Edit");
    } catch (err) {
      console.log("error editing: ", err);
    }
  };

  return (
    <div>
      <h1 className="font-bold text-3xl m-10">Todo NextJS + MongoDB</h1>

      <Link href="/add-todo">
        <button className="bg-green-600 p-2 rounded-lg ml-10 mb-5">
          Add Task
        </button>
      </Link>
      {/* <AddEditTodo /> */}

      <TodoDisplay
        handleDelete={handleDelete}
        handleEdit={handleEdit}
        todos={todo}
      />
    </div>
  );
}
