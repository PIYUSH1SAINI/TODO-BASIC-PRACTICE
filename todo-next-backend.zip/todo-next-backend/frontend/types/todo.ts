export type Todo = {
  _id: string;
  taskName: string;
};

export type TodoProps = {
  todos: Todo[];
  handleDelete: (id: string) => void;
  handleEdit: (taskName: string, id: string) => void;
};
