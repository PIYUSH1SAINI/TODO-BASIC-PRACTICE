(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_bf599dbd._.js",
  "static/chunks/app_add-todo_page_tsx_131dcbb1._.js"
],
    source: "dynamic"
});
