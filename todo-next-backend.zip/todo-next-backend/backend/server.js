const cors = require("cors");
const mongoose = require("mongoose");
const express = require("express");
const dotenv = require("dotenv");

const connectDB = require("./config/db");
const todos = require("./routes/todoRoutes");

dotenv.config();
connectDB();

const app = express();
app.use(cors());
app.use(express.json());

app.use("/api/todo", todos);

app.listen(process.env.PORT, () =>
  console.log("Server running at PORT:", process.env.PORT)
);
