const mongoose = require("mongoose");

const connectDB = async () => {
  try {
    await mongoose.connect(process.env.Mongo_URL);

    console.log("MongoDB connected");
  } catch (err) {
    console.log("error connection to mongoDB:", err);
  }
};

module.exports = connectDB;
