const Todo = require("../models/todoModel");

//fetch all
exports.getAll = async (req, res) => {
  try {
    const todos = await Todo.find();
    res.json(todos);
  } catch (err) {
    console.log("error fetching all todos:", err);
    res.status(500).json({ error: "Server Error" });
  }
};

// delete
exports.deleteTodo = async (req, res) => {
  try {
    const deleted = await Todo.findByIdAndDelete(req.params.id);

    if (!deleted) {
      return res.status(404).json({ error: "Todo not found" });
    }

    return res.status(200).json({ message: "Todo deleted" });
  } catch (err) {
    console.log("error deleting todo form backend:", err);

    res.status(500).json({ error: "Server Error" });
  }
};

// Add
exports.addTodo = async (req, res) => {
  try {
    const newTodo = new Todo(req.body);
    const saveTodo = await newTodo.save();

    res.status(201).json(saveTodo);
  } catch (err) {
    console.log("error adding todo form backend:", err);

    res.status(500).json({ error: "Server Error" });
  }
};

//edit
exports.editTodo = async (req, res) => {
  try {
    const editedTodo = await Todo.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });

    res.status(200).json({ message: "editing successful" });
  } catch (err) {
    console.log("error adding todo form backend:", err);

    res.status(500).json({ error: "Server Error" });
  }
};
