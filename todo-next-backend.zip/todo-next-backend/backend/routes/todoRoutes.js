const express = require("express");
const router = express.Router();

const {
  getAll,
  deleteTodo,
  addTodo,
  editTodo,
} = require("../controller/todoController");

router.get("/", getAll);
router.delete("/:id", deleteTodo);
router.post("/addTodo", addTodo);
router.put("/:id", editTodo);

module.exports = router;
