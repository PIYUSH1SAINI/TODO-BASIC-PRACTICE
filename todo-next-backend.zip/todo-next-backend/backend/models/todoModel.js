const mongoose = require("mongoose");

const todoModel = new mongoose.Schema({
  taskName: String,
});

module.exports = mongoose.model("Todo", todoModel);
