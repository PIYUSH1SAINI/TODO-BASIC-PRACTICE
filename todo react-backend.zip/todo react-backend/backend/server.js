const express = require("express");
const dotenv = require("dotenv");
const cors = require("cors");
const connectDb = require("./config/db");
const todos = require("./routes/todoRoutes");

dotenv.config();
connectDb();

const app = express();
app.use(cors());
app.use(express.json());

app.use("/api/todos", todos);

app.listen(process.env.PORT, () =>
  console.log("server running on PORT: ", process.env.PORT)
);
