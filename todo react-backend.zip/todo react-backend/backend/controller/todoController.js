const todos = require("../models/todoModel");

// fetch
exports.getTodos = async (req, res) => {
  try {
    const todo = await todos.find();
    res.json(todo);
  } catch (err) {
    console.error("Failed to fetch todos:", err);
    res.status(500).json({ error: "Server error" });
  }
};

// add
exports.addTodos = async (req, res) => {
  try {
    const newTodo = new todos(req.body);
    const saveTodo = await newTodo.save();
    res.status(201).json(saveTodo);
  } catch (err) {
    console.log("Error adding task to backend: ", err);
    res.status(500).json({ error: "server error" });
  }
};

// delete
exports.deleteTodo = async (req, res) => {
  try {
    const deleted = await todos.findByIdAndDelete(req.params.id);

    if (!deleted) {
      return res.status(404).json({ message: "Todo not found" });
    }

    return res.status(200).json({ message: "Todo deleted" });
  } catch (err) {
    console.log("error deleting: ", err);
    res.status(500).json({ error: "server error" });
  }
};

// edit
exports.editTodo = async (req, res) => {
  try {
    const editing = await todos.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });

    res.status(200).json(editing);
  } catch (err) {
    console.log("error deleting: ", err);
    res.status(500).json({ error: "server error" });
  }
};
