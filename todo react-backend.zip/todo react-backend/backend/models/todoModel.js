const mongoose = require("mongoose");

const todoScheme = new mongoose.Schema({
  taskName: String,
  // date: String,
});

module.exports = mongoose.model("Todo", todoScheme);
