const express = require("express");
const router = express.Router();
const {
  getTodos,
  addTodos,
  deleteTodo,
  editTodo,
} = require("../controller/todoController");

router.get("/", getTodos);
router.post("/", addTodos);
router.delete("/:id", deleteTodo);
router.put("/:id", editTodo);

module.exports = router;
