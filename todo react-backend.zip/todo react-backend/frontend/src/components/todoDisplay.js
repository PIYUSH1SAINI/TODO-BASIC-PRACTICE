import React, { useState } from "react";

function TodoDisplay({ task, deleteTask, editTask }) {
  const [editName, setEditName] = useState("");
  const [editId, setEditId] = useState(null);

  return (
    <div>
      {task.length > 0 ? (
        task.map((t) => (
          <div key={t._id}>
            {editId === t._id ? (
              <>
                <input
                  type="text"
                  placeholder="Enter task"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                />

                <button
                  onClick={() => {
                    editTask(t._id, editName);
                    setEditName("");
                    setEditId(null);
                  }}
                >
                  Save changes
                </button>
              </>
            ) : (
              <p>{t.taskName}</p>
            )}
            <div>
              <button onClick={() => deleteTask(t._id)}>Delete</button>
              <button
                onClick={() => {
                  setEditId(t._id);
                  setEditName(t.taskName);
                }}
              >
                Edit
              </button>
            </div>
          </div>
        ))
      ) : (
        <p>No tasks added yet</p>
      )}
    </div>
  );
}

export default TodoDisplay;
