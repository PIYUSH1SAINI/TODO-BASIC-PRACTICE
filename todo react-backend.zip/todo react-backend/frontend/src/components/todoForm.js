import { useState } from "react";

function ToDoForm({ addTask }) {
  const [taskname, setTaskname] = useState("");

  const handleSubmit = () => {
    if (taskname.trim() == "") return;

    addTask(taskname);
    setTaskname("");
  };

  return (
    <div>
      <input
        type="text"
        placeholder="enter task"
        value={taskname}
        onChange={(e) => setTaskname(e.target.value)}
      />

      <button onClick={handleSubmit}>Add Task</button>
    </div>
  );
}

export default ToDoForm;
