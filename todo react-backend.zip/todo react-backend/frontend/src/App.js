import ToDoForm from "./components/todoForm";
import TodoDisplay from "./components/todoDisplay";
import { useEffect, useState } from "react";
import axios from "axios";

function App() {
  const [Tasks, setTask] = useState([]);

  useEffect(() => {
    fetchTodos();
  }, []);

  //fetch
  const fetchTodos = async () => {
    try {
      const res = await axios.get("http://localhost:5001/api/todos");
      setTask(res.data);
    } catch (err) {
      console.log("error fetching todos:", err);
    }
  };

  //Delete
  const deleteTask = async (id) => {
    try {
      await axios.delete(`http://localhost:5001/api/todos/${id}`);

      alert("Todo deleted");

      fetchTodos();
    } catch (err) {
      console.log("error deleting todo: ", err);
    }
  };

  //edit
  const editTask = async (id, name) => {
    try {
      await axios.put(`http://localhost:5001/api/todos/${id}`, {
        taskName: name,
      });

      fetchTodos();
    } catch (err) {
      console.log("error deleting todo: ", err);
    }
  };

  //Add
  const addTask = async (taskName) => {
    try {
      const res = await axios.post("http://localhost:5001/api/todos", {
        taskName,
      });

      console.log("data saved : ", res.data);

      fetchTodos();
    } catch (err) {
      console.error("Error adding todo:", err);
    }
  };

  return (
    <div>
      <h1>ToDo list using React and mongoDB</h1>

      <TodoDisplay task={Tasks} deleteTask={deleteTask} editTask={editTask} />
      <ToDoForm addTask={addTask} />
    </div>
  );
}

export default App;
